# Simple Snake Game in Python 3 for Beginners
# By @TokyoEdTech
import turtle
import time
import random
delay = 0.1

# Score
score = 0
high_score = 0

# Set up the screen
wn = turtle.Screen()
wn.title("Snake Game by @TokyoEdTech")
wn.bgcolor("green")
wn.setup(width=600, height=600)