#!/bin/bash

# Declare the argument variable
argument="--continuous"

# Call the run.sh script with the argument
./run.sh "$argument"
